import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { Eye, EyeOff, LogIn, UserPlus } from 'lucide-react';
import { authAPI } from '../api';

export default function LoginPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [form, setForm] = useState({ 
    email: 'daynriley@gmail.com', 
    password: 'Marie_tte637',
    name: '',
    role: 'operator'
  });
  const [showPwd, setShowPwd] = useState(false);
  const [loading, setLoading] = useState(false);
  
  const { login } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (isLogin) {
        await login({ email: form.email, password: form.password });
        toast('Connexion réussie ! Bienvenue sur Minetrack', 'success');
        navigate('/dashboard');
      } else {
        await authAPI.register(form);
        toast('Compte créé avec succès ! Bienvenue.', 'success');
        // Auto login after register
        await login({ email: form.email, password: form.password });
        navigate('/dashboard');
      }
    } catch (err) {
      toast(err.response?.data?.detail || (isLogin ? 'Email ou mot de passe incorrect' : 'Erreur lors de la création du compte'), 'error');
    } finally {
      setLoading(false);
    }
  };

  const toggleMode = () => {
    setIsLogin(!isLogin);
    if (!isLogin) {
      setForm({ ...form, email: 'daynriley@gmail.com', password: 'Marie_tte637' });
    } else {
      setForm({ ...form, email: '', password: '', name: '' });
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-card" style={{ maxWidth: '400px', width: '100%' }}>
        <div className="auth-logo">
          <div className="auth-logo-icon">⛏️</div>
          <div>
            <h2 style={{ background: 'linear-gradient(90deg, var(--color-ore), var(--color-gold))', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>
              Minetrack
            </h2>
            <p className="text-muted text-sm">Plateforme de Gestion Minière</p>
          </div>
        </div>

        <h3 style={{ marginBottom: '0.5rem' }}>{isLogin ? 'Connexion' : 'Créer un compte'}</h3>
        <p className="text-muted text-sm mb-6">
          {isLogin ? 'Accédez à votre tableau de bord minier' : 'Rejoignez la plateforme Minetrack'}
        </p>

        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          
          {!isLogin && (
            <div className="form-group">
              <label className="form-label">Nom complet</label>
              <input
                type="text"
                className="form-input"
                placeholder="Votre nom"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                required={!isLogin}
              />
            </div>
          )}

          <div className="form-group">
            <label className="form-label">Adresse Email</label>
            <input
              type="email"
              className="form-input"
              placeholder="votre@email.com"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Mot de Passe</label>
            <div style={{ position: 'relative' }}>
              <input
                type={showPwd ? 'text' : 'password'}
                className="form-input"
                placeholder="••••••••"
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
                style={{ paddingRight: '2.5rem' }}
                required
              />
              <button
                type="button"
                className="btn btn-ghost btn-icon btn-sm"
                style={{ position: 'absolute', right: '0.5rem', top: '50%', transform: 'translateY(-50%)' }}
                onClick={() => setShowPwd(!showPwd)}
              >
                {showPwd ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          <button type="submit" className="btn btn-primary btn-lg w-full" disabled={loading} style={{ marginTop: '0.5rem' }}>
            {loading ? (
              <><div className="loading-spinner" style={{ width: 18, height: 18, borderWidth: 2 }}></div> {isLogin ? 'Connexion…' : 'Création…'}</>
            ) : (
              <>{isLogin ? <LogIn size={18} /> : <UserPlus size={18} />} {isLogin ? 'Se Connecter' : 'Créer mon compte'}</>
            )}
          </button>
        </form>

        <div style={{ textAlign: 'center', marginTop: '1rem' }}>
          <button 
            type="button" 
            onClick={toggleMode}
            className="btn btn-ghost btn-sm"
            style={{ color: 'var(--color-ash)' }}
          >
            {isLogin ? "Je n'ai pas de compte ? S'inscrire" : "J'ai déjà un compte ? Se connecter"}
          </button>
        </div>

        {isLogin && (
          <>
            <div className="divider"></div>
            <div style={{ background: 'var(--color-rock)', borderRadius: 'var(--radius-md)', padding: '0.75rem 1rem', fontSize: '0.8rem' }}>
              <p className="text-muted text-xs" style={{ marginBottom: '0.25rem', fontWeight: 600 }}>Compte Administrateur par défaut :</p>
              <p className="text-xs" style={{ color: 'var(--color-ash)' }}>Email: <span className="text-ore">daynriley@gmail.com</span></p>
              <p className="text-xs" style={{ color: 'var(--color-ash)' }}>Mot de passe: <span className="text-ore">Marie_tte637</span></p>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
