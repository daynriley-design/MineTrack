import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { ToastProvider } from './contexts/ToastContext';
import ProtectedRoute from './components/ProtectedRoute';
import Layout from './components/Layout';

// Pages
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import PegsPage from './pages/PegsPage';
import WorkProgressPage from './pages/WorkProgressPage';
import DrillingPage from './pages/DrillingPage';
import BlastingPage from './pages/BlastingPage';
import ProductionPage from './pages/ProductionPage';
import EquipmentPage from './pages/EquipmentPage';
import LaborPage from './pages/LaborPage';
import HSEPage from './pages/HSEPage';
import GeologyPage from './pages/GeologyPage';
import SupportPage from './pages/SupportPage';
import FinancialPage from './pages/FinancialPage';
import ReportsPage from './pages/ReportsPage';

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <ToastProvider>
          <Routes>
            {/* Public */}
            <Route path="/login" element={<LoginPage />} />

            {/* Protected — wrapped in Layout */}
            <Route
              path="/"
              element={
                <ProtectedRoute>
                  <Layout />
                </ProtectedRoute>
              }
            >
              <Route index element={<Navigate to="/dashboard" replace />} />
              <Route path="dashboard"     element={<DashboardPage />} />
              <Route path="pegs"          element={<PegsPage />} />
              <Route path="work-progress" element={<WorkProgressPage />} />
              <Route path="drilling"      element={<DrillingPage />} />
              <Route path="blasting"      element={<BlastingPage />} />
              <Route path="production"    element={<ProductionPage />} />
              <Route path="equipment"     element={<EquipmentPage />} />
              <Route path="labor"         element={<LaborPage />} />
              <Route path="hse"           element={<HSEPage />} />
              <Route path="geology"       element={<GeologyPage />} />
              <Route path="support"       element={<SupportPage />} />
              <Route path="financial"     element={<FinancialPage />} />
              <Route path="reports"       element={<ReportsPage />} />
            </Route>

            {/* Catch-all */}
            <Route path="*" element={<Navigate to="/dashboard" replace />} />
          </Routes>
        </ToastProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
